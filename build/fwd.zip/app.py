import os
import logging
from flask import Flask, render_template, request, jsonify
from chatbot import BusinessChatbot

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default_secret_key")

# Initialize chatbot
chatbot = BusinessChatbot()

@app.route('/')
def index():
    """Render the main chat interface."""
    return render_template('index.html', 
                          business_name="Business Support Bot",
                          business_hours="Monday-Friday: 9am-5pm",
                          business_contact="contact@business.com | (555) 123-4567")

@app.route('/api/chat', methods=['POST'])
def chat():
    """Process chat messages from the user and return a response."""
    try:
        data = request.json
        user_message = data.get('message', '').strip()
        conversation_history = data.get('history', [])
        
        if not user_message:
            return jsonify({'error': 'Empty message'}), 400
        
        logger.debug(f"Received message: {user_message}")
        logger.debug(f"Conversation history: {conversation_history}")
        
        # Get response from chatbot - the chatbot has its own error handling
        response = chatbot.get_response(user_message, conversation_history)
        
        # If we got a response, send it back
        if response:
            return jsonify({'response': response})
        else:
            # Fallback if response is None or empty
            return jsonify({
                'response': "I'm sorry, I couldn't understand that. Could you please try again?"
            })
    
    except Exception as e:
        logger.error(f"Error processing message: {str(e)}", exc_info=True)
        return jsonify({
            'response': "I'm having trouble understanding you right now. Please try asking a simple question."
        })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)