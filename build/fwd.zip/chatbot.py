import json
import os
import re
import random
import logging
from pathlib import Path

# Import DeepSeek API
try:
    from deepseek import api
    DEEPSEEK_AVAILABLE = True
except ImportError:
    DEEPSEEK_AVAILABLE = False
    print("DeepSeek module not available")

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class BusinessChatbot:
    def __init__(self):
        """Initialize the business chatbot."""
        
        # Common English stopwords (simplified list)
        self.stop_words = {
            'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', 'your', 
            'yours', 'yourself', 'yourselves', 'he', 'him', 'his', 'himself', 'she', 
            'her', 'hers', 'herself', 'it', 'its', 'itself', 'they', 'them', 'their', 
            'theirs', 'themselves', 'what', 'which', 'who', 'whom', 'this', 'that', 
            'these', 'those', 'am', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 
            'have', 'has', 'had', 'having', 'do', 'does', 'did', 'doing', 'a', 'an', 
            'the', 'and', 'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of', 
            'at', 'by', 'for', 'with', 'about', 'against', 'between', 'into', 'through', 
            'during', 'before', 'after', 'above', 'below', 'to', 'from', 'up', 'down', 
            'in', 'out', 'on', 'off', 'over', 'under', 'again', 'further', 'then', 
            'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'any', 
            'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 
            'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 's', 
            't', 'can', 'will', 'just', 'don', 'should', 'now'
        }
        
        # Simple stemming mappings (much simpler than WordNet lemmatizer)
        self.stem_dict = {
            'running': 'run', 'runs': 'run', 'ran': 'run',
            'walking': 'walk', 'walks': 'walk', 'walked': 'walk',
            'talking': 'talk', 'talks': 'talk', 'talked': 'talk',
            'saying': 'say', 'says': 'say', 'said': 'say',
            'looking': 'look', 'looks': 'look', 'looked': 'look',
            'hours': 'hour', 'pricing': 'price', 'prices': 'price',
            'contacting': 'contact', 'contacts': 'contact', 'contacted': 'contact',
            'shipping': 'ship', 'ships': 'ship', 'shipped': 'ship',
            'products': 'product', 'services': 'service',
            'helping': 'help', 'helps': 'help', 'helped': 'help',
            'issues': 'issue', 'problems': 'problem'
        }
        
        # Load response data
        self.responses = self._load_responses()
        
        # Track context for follow-up questions
        self.context = {}
        
        # Initialize DeepSeek API client
        try:
            self.deepseek_api = api.DeepSeekAPI(api_key=os.environ.get("DEEPSEEK_API_KEY"))
            self.use_ai = True
            logger.debug("DeepSeek API initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize DeepSeek API: {str(e)}")
            self.use_ai = False
        
        # List of intents that should always use predefined responses
        self.fixed_intents = ["business_hours", "contact_info", "greeting", "goodbye"]
        
        logger.debug("BusinessChatbot initialized successfully")
    
    def _load_responses(self):
        """Load predefined responses from JSON file."""
        try:
            response_file = Path(__file__).parent / 'static' / 'data' / 'responses.json'
            with open(response_file, 'r') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            logger.error(f"Error loading responses: {str(e)}")
            # Fallback to embedded responses if file can't be loaded
            return {
                "greeting": [
                    "Hello! How can I help you today?",
                    "Welcome to our business chat support. How may I assist you?",
                    "Hi there! What can I help you with today?"
                ],
                "business_hours": [
                    "Our business hours are Monday through Friday, 9am to 5pm.",
                    "We're open weekdays from 9am to 5pm."
                ],
                "contact_info": [
                    "You can reach us at contact@business.com or call (555) 123-4567.",
                    "For immediate assistance, please call (555) 123-4567 or email contact@business.com."
                ],
                "product_info": [
                    "We offer a range of products and services. Could you specify which one you're interested in?",
                    "Our products include software solutions, consulting services, and support packages. What would you like to know more about?"
                ],
                "pricing": [
                    "Our pricing varies based on the specific product or service. Could you let me know which one you're interested in?",
                    "Pricing information can be found on our website or I can help you with a specific product's pricing."
                ],
                "support": [
                    "For technical support, please describe your issue and I'll try to help or direct you to the right resource.",
                    "I can help with basic troubleshooting or connect you with our support team for more complex issues."
                ],
                "refund_policy": [
                    "Our refund policy allows returns within 30 days of purchase with a valid receipt.",
                    "We offer refunds within 30 days of the original purchase date."
                ],
                "shipping": [
                    "Standard shipping takes 3-5 business days. Express shipping options are also available.",
                    "We ship to most countries worldwide with delivery times ranging from 3-10 business days depending on location."
                ],
                "feedback": [
                    "We appreciate your feedback! Is there something specific you'd like to share about our products or services?",
                    "Thank you for your interest in providing feedback. Would you like to tell me more about your experience?"
                ],
                "human_assistance": [
                    "It seems like you might need assistance from one of our human representatives. Would you like me to arrange that?",
                    "For this specific inquiry, it might be best to speak with a human agent. Would you like me to connect you?"
                ],
                "fallback": [
                    "I apologize, but I'm not sure I understand your question. Could you rephrase that?",
                    "I'm sorry, I don't have information on that topic. Would you like to ask something else?",
                    "I don't have enough information to answer that properly. Could you provide more details?"
                ],
                "goodbye": [
                    "Thank you for chatting with us today! Is there anything else I can help you with?",
                    "I hope I was able to assist you. Have a great day!",
                    "Thank you for contacting our business support. Feel free to reach out again if you need anything else."
                ]
            }
    
    def _preprocess_text(self, text):
        """Preprocess text by converting to lowercase, tokenizing, removing stopwords, and applying simple stemming."""
        if not text:
            return []
            
        # Use simple tokenization
        text_lower = text.lower()
        
        # Remove punctuation for better tokenization
        for char in '.,!?;:()[]{}"\'-':
            text_lower = text_lower.replace(char, ' ')
            
        tokens = text_lower.split()
        
        # Filter tokens and apply stemming
        filtered_tokens = []
        for token in tokens:
            if token.isalnum() and token not in self.stop_words:
                # Apply our simple stemming dictionary
                stemmed_token = self.stem_dict.get(token, token)
                filtered_tokens.append(stemmed_token)
                    
        return filtered_tokens
    
    def _extract_keywords(self, tokens):
        """Extract important keywords from the preprocessed tokens."""
        # You can expand this with more business-specific keywords
        business_keywords = {
            'hours': 'business_hours',
            'open': 'business_hours', 
            'closed': 'business_hours',
            'contact': 'contact_info',
            'email': 'contact_info',
            'phone': 'contact_info',
            'call': 'contact_info',
            'reach': 'contact_info',
            'product': 'product_info',
            'service': 'product_info',
            'offer': 'product_info',
            'price': 'pricing',
            'cost': 'pricing',
            'fee': 'pricing',
            'support': 'support',
            'help': 'support',
            'issue': 'support',
            'problem': 'support',
            'troubleshoot': 'support',
            'refund': 'refund_policy',
            'return': 'refund_policy',
            'money': 'refund_policy',
            'ship': 'shipping',
            'delivery': 'shipping',
            'feedback': 'feedback',
            'review': 'feedback',
            'opinion': 'feedback',
            'suggest': 'feedback',
            'human': 'human_assistance',
            'agent': 'human_assistance',
            'person': 'human_assistance',
            'representative': 'human_assistance',
            'hello': 'greeting',
            'hi': 'greeting',
            'hey': 'greeting',
            'bye': 'goodbye',
            'goodbye': 'goodbye',
            'thank': 'goodbye'
        }
        
        found_keywords = []
        for token in tokens:
            if token in business_keywords:
                found_keywords.append(business_keywords[token])
        
        return found_keywords
    
    def _detect_intent(self, text, tokens, keywords):
        """Determine the user's intent based on text, tokens, and keywords."""
        if not text:
            return 'fallback'
            
        text_lower = text.lower()
        
        # Check for greetings
        if any(greeting in text_lower for greeting in ['hello', 'hi', 'hey', 'greetings']):
            return 'greeting'
        
        # Check for goodbyes
        if any(bye in text_lower for bye in ['bye', 'goodbye', 'thank you', 'thanks']):
            if not any(help_word in text_lower for help_word in ['help', 'question', 'need']):
                return 'goodbye'
        
        # Check for business hours
        if any(hour_word in text_lower for hour_word in ['hour', 'open', 'close', 'time']):
            return 'business_hours'
            
        # Check for contact info
        if any(contact_word in text_lower for contact_word in ['contact', 'phone', 'email', 'call']):
            return 'contact_info'
        
        # Use the first keyword found as the intent, or fallback if none
        return keywords[0] if keywords else 'fallback'
    
    def _handle_follow_up(self, text, conversation_history):
        """Handle follow-up questions based on conversation context."""
        # Check if this could be a follow-up to the last bot response
        if conversation_history and len(conversation_history) >= 2:
            last_bot_message = conversation_history[-1].get('bot', '')
            last_user_message = conversation_history[-2].get('user', '')
            
            # Check for follow-up indicators
            if re.search(r'\b(yes|yeah|sure|ok|okay|please)\b', text.lower()):
                # If we previously asked about connecting to a human
                if "human" in last_bot_message.lower() or "agent" in last_bot_message.lower():
                    return "I'll arrange for a human agent to contact you. Please provide your preferred contact method (email or phone)."
                
                # If we previously asked about specific products
                if "which product" in last_bot_message.lower() or "which service" in last_bot_message.lower():
                    return "Great! I can provide detailed information about specific products. Could you tell me which product you're interested in?"
            
            # Check for negative responses to follow-ups
            if re.search(r'\b(no|nope|not now|later)\b', text.lower()):
                return "Alright. Is there something else I can help you with today?"
        
        return None
    
    def _generate_ai_response(self, user_message, conversation_history=None):
        """Generate a response using DeepSeek AI."""
        try:
            if not self.use_ai:
                return None  # Fall back to predefined responses
                
            # Prepare conversation context for AI
            system_prompt = """You are a helpful business assistant chatbot. 
            Your job is to provide accurate, concise, and friendly responses to customer inquiries.
            Keep your responses professional, helpful, and focused on the question.
            
            Business details:
            - Business hours: Monday-Friday, 9am-5pm
            - Contact: contact@business.com, (555) 123-4567
            - Products: Software solutions, consulting services, and support packages
            - Shipping: 3-5 business days standard, express options available
            - Refunds: Allowed within 30 days of purchase with receipt
            """
            
            # Format previous conversation if available
            chat_context = ""
            if conversation_history and len(conversation_history) > 0:
                # Process only the last 5 exchanges at most to stay within context limits
                recent_history = conversation_history[-10:] if len(conversation_history) > 10 else conversation_history
                for item in recent_history:
                    if 'user' in item:
                        chat_context += f"Customer: {item['user']}\n"
                    if 'bot' in item:
                        chat_context += f"Assistant: {item['bot']}\n"
            
            # Combine everything into the prompt
            full_prompt = f"{chat_context}Customer: {user_message}\nAssistant:"
            
            # Call DeepSeek API
            response = self.deepseek_api.chat_completion(
                prompt=full_prompt,
                prompt_sys=system_prompt,
                model="deepseek-chat",
                temperature=0.5  # Balanced between creativity and consistency
            )
            
            # Process and return the response
            if response and hasattr(response, 'choices') and len(response.choices) > 0:
                generated_text = response.choices[0].message.content.strip()
                return generated_text
            return None
            
        except Exception as e:
            logger.error(f"Error generating AI response: {str(e)}")
            return None
            
    def get_response(self, user_message, conversation_history=None):
        """Generate a response based on the user message and conversation history."""
        try:
            if conversation_history is None:
                conversation_history = []
            
            # Check for follow-up responses first
            follow_up_response = self._handle_follow_up(user_message, conversation_history)
            if follow_up_response:
                return follow_up_response
            
            # Preprocess the user message
            tokens = self._preprocess_text(user_message)
            keywords = self._extract_keywords(tokens)
            intent = self._detect_intent(user_message, tokens, keywords)
            
            logger.debug(f"Detected intent: {intent}")
            
            # For certain intents, always use predefined responses
            if intent in self.fixed_intents and intent in self.responses:
                return random.choice(self.responses[intent])
                
            # For other intents, try AI response first, fallback to predefined
            if self.use_ai:
                logger.debug("Attempting to get AI response")
                ai_response = self._generate_ai_response(user_message, conversation_history)
                if ai_response:
                    logger.debug("Returning AI generated response")
                    return ai_response
                logger.debug("AI response generation failed, falling back to predefined responses")
            
            # If AI failed or is disabled, use predefined responses
            if intent in self.responses:
                return random.choice(self.responses[intent])
            else:
                return random.choice(self.responses["fallback"])
                
        except Exception as e:
            logger.error(f"Error in get_response: {str(e)}")
            return "I'm having trouble understanding your request. Could you please rephrase that?"
